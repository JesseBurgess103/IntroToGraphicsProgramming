#Source File: AssignmentTwo.py
#Author: Jesse Burgess
#Last Modified By: Jesse Burgess
#Date Last Modified: June 6, 2013
#Purpose: A simple slot machine game
#Version 1.0

#Imports
from Tkinter import *
import tkFont
import winsound
import random


class MyApp:
    def __init__(self, parent):
                
        #create the frame
        self.myContainer1 = Frame(parent)
        self.myContainer1["background"] = "black"
        
         
        #show the frame
        self.myContainer1.pack()
         
        #decare variables
        self.playerMoney = 1500
        self.betTotal = 0
                 
        #the total cash label
        self.totalCash = Label(self.myContainer1, text="Total Cash: $"+self.playerMoney.__str__(), width=20)
        self.totalCash["foreground"] = "white"
        self.totalCash["background"] = "black"
        self.totalCash.grid(row=0,column=0)
         
        #the bet ammount label
        self.betAmmount = Label(self.myContainer1, text="Bet Ammount: $"+self.betTotal.__str__(), width=20)
        self.betAmmount["foreground"] = "white"
        self.betAmmount["background"] = "black"
        self.betAmmount.grid(row=1,column=0)
        
        #set the message label
        self.customFont = tkFont.Font(family="Helvetica", size=14)
        self.messageLabel = Label(self.myContainer1, text="Place your bet!!!", font=self.customFont)
        self.messageLabel["foreground"] = "white"
        self.messageLabel["background"] = "black"
        self.messageLabel.grid(row=4,column=3)
        
        #Add the header
        self.headerImage = PhotoImage(file="header.gif")
        self.headerLable = Label(self.myContainer1, image=self.headerImage)
        self.headerLable.grid(row=0,column=3, rowspan=2)
        
        #Add side image
        self.sideImage = PhotoImage(file="charizard.gif")
        self.sideLabel = Label(self.myContainer1, image=self.sideImage, border=0)
        self.sideLabel.grid(row=3,column=5,columnspan=4)
         
         
        #the slot machine images
        self.slotLabel = [" "," "," "]
        self.emptyReel = PhotoImage(file="frame.gif")
        self.grapeReel = PhotoImage(file="ball.gif")
        self.bananaReel = PhotoImage(file="pikachu.gif")
        self.orangeReel = PhotoImage(file="bulbasaur.gif")
        self.cherryReel = PhotoImage(file="geodude.gif")
        self.bellReel = PhotoImage(file="arbok.gif")
        self.barReel = PhotoImage(file="charmeleon.gif")
        self.sevenReel = PhotoImage(file="dragonite.gif")
        self.slotLabel[0] = Label(self.myContainer1, image=self.emptyReel)
        self.slotLabel[0].grid(row=3,column=2,padx=5,pady=5)
        self.slotLabel[1] = Label(self.myContainer1, image=self.emptyReel)
        self.slotLabel[1].grid(row=3,column=3,padx=5,pady=5)
        self.slotLabel[2] = Label(self.myContainer1, image=self.emptyReel)
        self.slotLabel[2].grid(row=3,column=4,padx=5,pady=5)
         
        #the button attributes
        self.betButton = Button(self.myContainer1, command=self.betButtonClick, width=10)
        self.betButton["text"]= "BET $100"
        self.betButton["background"] = "black"
        self.betButton["foreground"] = "white"
        self.spinButton = Button(self.myContainer1, command=self.spinButtonClick, width=10)
        self.spinButton["text"]= "SPIN"
        self.spinButton["background"] = "gray"
        self.spinButton["state"] = "disabled"
        self.quitButton = Button(self.myContainer1, command=quit, width=10)
        self.quitButton["text"]= "QUIT"
        self.quitButton["background"] = "black"
        self.quitButton["foreground"] = "white"
        self.resetButton = Button(self.myContainer1, command=self.resetButtonClick, width=10)
        self.resetButton["text"]="RESET"
        self.resetButton["background"] = "gray"
        self.resetButton["state"] = "disabled"
    
                 
        #display the buttons
        self.betButton.grid(row=0,column=5)
        self.spinButton.grid(row=0,column=6)
        self.quitButton.grid(row=0,column=7)
        self.resetButton.grid(row=0,column=8)
        
        
    def resetButtonClick(self):
        #resets the game
        winsound.PlaySound("whoosh.wav",winsound.SND_FILENAME)
        self.slotLabel[0]["image"] = self.emptyReel
        self.slotLabel[1]["image"] = self.emptyReel
        self.slotLabel[2]["image"] = self.emptyReel
        self.playerMoney = 1500
        self.betButton["state"] = "normal"
        self.betButton["background"] = "black"
        self.betButton["foreground"] = "white"
        self.resetButton["state"] = "disabled"
        self.resetButton["background"] = "gray"
        self.totalCash["text"]="Total Cash: $"+self.playerMoney.__str__()
        self.messageLabel["text"]="Place your bet!!!"
        
        
         
    def betButtonClick(self):
        #when the user clicks bet
        if self.playerMoney >= 100:
            winsound.PlaySound("button-19.wav",winsound.SND_FILENAME)
            self.playerMoney = self.playerMoney - 100
            self.betTotal = self.betTotal +100        
            self.betAmmount["text"]="Bet Ammount: $"+self.betTotal.__str__()
            self.totalCash["text"]="Total Cash: $"+self.playerMoney.__str__()
            
            #enable the spin button
            self.spinButton["state"] = "normal"
            self.spinButton["background"] = "black"
            self.spinButton["foreground"] = "white"
        else:
            #no money to bet
            winsound.PlaySound("button-28.wav",winsound.SND_FILENAME)
            
    def spinButtonClick(self):
        #when the user clicks spin
        winsound.PlaySound("lever.wav",winsound.SND_FILENAME)
        #disable the spin button
        self.spinButton["state"] = "disabled"
        self.spinButton["background"] = "gray"
                    
        win = False
        Fruit_Reel = self.Reels()
        Fruits = Fruit_Reel[0] + " - " + Fruit_Reel[1] + " - " + Fruit_Reel[2]
        
        # Match 3
        if Fruit_Reel.count("Grapes") == 3:
            winnings,win = self.betTotal*20,True
        elif Fruit_Reel.count("Banana") == 3:
            winnings,win = self.betTotal*30,True
        elif Fruit_Reel.count("Orange") == 3:
            winnings,win = self.betTotal*40,True
        elif Fruit_Reel.count("Cherry") == 3:
            winnings,win = self.betTotal*100,True
        elif Fruit_Reel.count("Bar") == 3:
            winnings,win = self.betTotal*200,True
        elif Fruit_Reel.count("Bell") == 3:
            winnings,win = self.betTotal*300,True
        elif Fruit_Reel.count("Seven") == 3:
            print("Lucky Seven!!!")
            winnings,win = self.betTotal*1000,True
        # Match 2
        elif Fruit_Reel.count("Blank") == 0:
            if Fruit_Reel.count("Grapes") == 2:
                winnings,win = self.betTotal*2,True
            if Fruit_Reel.count("Banana") == 2:
                winnings,win = self.betTotal*2,True
            elif Fruit_Reel.count("Orange") == 2:
                winnings,win = self.betTotal*3,True
            elif Fruit_Reel.count("Cherry") == 2:
                winnings,win = self.betTotal*4,True
            elif Fruit_Reel.count("Bar") == 2:
                winnings,win = self.betTotal*5,True
            elif Fruit_Reel.count("Bell") == 2:
                winnings,win = self.betTotal*10,True
            elif Fruit_Reel.count("Seven") == 2:
                winnings,win = self.betTotal*20,True
        
            # Match Lucky Seven
            elif Fruit_Reel.count("Seven") == 1:
                winnings, win = self.betTotal*10,True
                
            else:
                winnings, win = self.betTotal*2,True
        
        #win
        if win:            
            self.messageLabel["text"]="You win $"+str(int(winnings))  
            self.playerMoney += int(winnings)
            self.totalCash["text"]="Total Cash: $"+self.playerMoney.__str__()
            self.betTotal = -0       
            self.betAmmount["text"]="Bet Ammount: $"+self.betTotal.__str__()
            #winsound.PlaySound("winning.wav",winsound.SND_FILENAME) 
        #lose
        else:
            self.messageLabel["text"]="You lost! Try again!" 
            self.betTotal = -0       
            self.betAmmount["text"]="Bet Ammount: $"+self.betTotal.__str__()
            #winsound.PlaySound("losing.wav",winsound.SND_FILENAME)
            
        if self.playerMoney == 0:
            #when the player has no money left
            self.betButton["state"] = "disabled"
            self.betButton["background"] = "gray"
            self.resetButton["state"] = "normal"
            self.resetButton["background"] = "black"
            self.resetButton["foreground"] = "white"
            
            
            
    def Reels(self):   
        Bet_Line = [" "," "," "]
        Outcome = [0,0,0]
        
        # Spin those reels
        for spin in range(3):
            Outcome[spin] = random.randrange(1,65,1)
            # Spin those Reels!
            if Outcome[spin] >= 1 and Outcome[spin] <=26:   # 40.10% Chance
                Bet_Line[spin] = "Blank"
                self.slotLabel[spin]["image"] = self.emptyReel
            if Outcome[spin] >= 27 and Outcome[spin] <=36:  # 16.15% Chance
                Bet_Line[spin] = "Grapes"
                self.slotLabel[spin]["image"] = self.grapeReel
            if Outcome[spin] >= 37 and Outcome[spin] <=45:  # 13.54% Chance
                Bet_Line[spin] = "Banana"
                self.slotLabel[spin]["image"] = self.bananaReel
            if Outcome[spin] >= 46 and Outcome[spin] <=53:  # 11.98% Chance
                Bet_Line[spin] = "Orange"
                self.slotLabel[spin]["image"] = self.orangeReel
            if Outcome[spin] >= 54 and Outcome[spin] <=58:  # 7.29%  Chance
                Bet_Line[spin] = "Cherry"
                self.slotLabel[spin]["image"] = self.cherryReel
            if Outcome[spin] >= 59 and Outcome[spin] <=61:  # 5.73%  Chance
                Bet_Line[spin] = "Bar"
                self.slotLabel[spin]["image"] = self.barReel
            if Outcome[spin] >= 62 and Outcome[spin] <=63:  # 3.65%  Chance
                Bet_Line[spin] = "Bell"
                self.slotLabel[spin]["image"] = self.bellReel  
            if Outcome[spin] == 64:                         # 1.56%  Chance
                Bet_Line[spin] = "Seven"
                self.slotLabel[spin]["image"] = self.sevenReel    
    
        
        return Bet_Line

         
#create a top-level window
root = Tk()
 
myapp = MyApp(root)

#execute the mainloop method of the "root" object
root.mainloop()

     
 


